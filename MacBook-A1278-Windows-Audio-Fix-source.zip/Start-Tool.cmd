@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0New-AudioFixUsb.ps1" %*
set "TOOL_EXIT_CODE=%ERRORLEVEL%"
echo.
if not "%TOOL_EXIT_CODE%"=="0" echo The USB was not prepared successfully.
pause
exit /b %TOOL_EXIT_CODE%
