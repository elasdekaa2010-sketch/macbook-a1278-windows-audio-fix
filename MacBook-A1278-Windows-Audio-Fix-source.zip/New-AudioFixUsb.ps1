[CmdletBinding()]
param(
    [ValidatePattern('^[A-Za-z]$')]
    [string]$DriveLetter
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Invoke-Main {
    $expectedFiles = [ordered]@{
        'BOOT\BOOTx64.efi'       = '4BFB36B5235D1743088E39F4C3F7C0EE1A7FD1E52F9DA8F8E85836EC37FC469C'
        'OC\config.plist'         = '5CE1AFFD8D84AB3F447C0BC8746A7DE63D952A12DD9722AE8B80B720F8C0CB22'
        'OC\OpenCore.efi'         = '0A51419DDA3F4555E4C472ADC480A91310622194E1FDEF3DB536ACF1CCB75FFE'
        'OC\ACPI\SSDT-PCI.aml'    = 'C0ECFB9CF78B7FA9CFB37FE7AC7E1764F65FDDB85955CD7DDD8506154C8ACCDE'
        'OC\Drivers\OpenRuntime.efi' = 'C88586F482E8948BFE69208AE77C0F6DEFBC7841852DED078C5AD2D0ADEE7AD0'
    }

    $efiSource = Join-Path $PSScriptRoot 'Payload\EFI'
    if (-not (Test-Path -LiteralPath $efiSource -PathType Container)) {
        throw "Payload folder is missing: $efiSource"
    }

    Write-Host 'Checking the bundled EFI files...' -ForegroundColor Cyan
    foreach ($relativePath in $expectedFiles.Keys) {
        $sourceFile = Join-Path $efiSource $relativePath
        if (-not (Test-Path -LiteralPath $sourceFile -PathType Leaf)) {
            throw "Payload file is missing: $relativePath"
        }
        $actualHash = (Get-FileHash -LiteralPath $sourceFile -Algorithm SHA256).Hash.ToUpperInvariant()
        if ($actualHash -ne $expectedFiles[$relativePath]) {
            throw "Payload integrity check failed: $relativePath"
        }
    }

    $removableFat32 = @(
        Get-CimInstance -ClassName Win32_LogicalDisk |
            Where-Object { $_.DriveType -eq 2 -and $_.FileSystem -eq 'FAT32' } |
            Sort-Object -Property DeviceID
    )

    if (-not $DriveLetter) {
        if ($removableFat32.Count -eq 0) {
            throw 'No removable FAT32 USB volume was found. Prepare a USB drive as FAT32, reconnect it, then run this tool again.'
        }
        Write-Host ''
        Write-Host 'Removable FAT32 volumes:' -ForegroundColor Cyan
        foreach ($volume in $removableFat32) {
            $freeMB = [math]::Round($volume.FreeSpace / 1MB)
            Write-Host ("  {0}  Label: {1}  Free: {2} MB" -f $volume.DeviceID, $volume.VolumeName, $freeMB)
        }
        $DriveLetter = Read-Host 'Enter the USB drive letter only (for example E)'
    }

    $DriveLetter = $DriveLetter.Trim().TrimEnd(':').ToUpperInvariant()
    if ($DriveLetter -notmatch '^[A-Z]$') {
        throw 'Enter one drive letter only, such as E.'
    }

    $deviceId = "${DriveLetter}:"
    $volume = Get-CimInstance -ClassName Win32_LogicalDisk -Filter "DeviceID='$deviceId'"
    if ($null -eq $volume) { throw "Drive $deviceId was not found." }
    if ($volume.DriveType -ne 2) { throw "Drive $deviceId is not reported by Windows as a removable drive. No files were written." }
    if ($volume.FileSystem -ne 'FAT32') { throw "Drive $deviceId must be FAT32. This tool will not format it." }
    if ($deviceId -eq $env:SystemDrive) { throw 'Refusing to write to the Windows system drive.' }
    if ($volume.FreeSpace -lt 3MB) { throw 'The selected volume needs at least 3 MB of free space.' }

    $targetRoot = $deviceId + '\'
    $targetEfi = Join-Path $targetRoot 'EFI'
    if (Test-Path -LiteralPath $targetEfi) {
        throw "An EFI folder already exists on $deviceId. Nothing was changed. Use an empty USB volume so existing boot files are not overwritten."
    }

    Write-Host ''
    Write-Host 'Ready to copy the tested EFI files to this volume:' -ForegroundColor Yellow
    Write-Host ("  Drive: {0}  Label: {1}  File system: {2}" -f $deviceId, $volume.VolumeName, $volume.FileSystem)
    Write-Host 'The tool will create only the EFI folder. It will not format the USB or modify Windows files.'
    $confirmation = Read-Host 'Type COPY to continue'
    if ($confirmation -cne 'COPY') { throw 'Cancelled. The USB was not changed.' }

    Copy-Item -LiteralPath $efiSource -Destination $targetRoot -Recurse

    foreach ($relativePath in $expectedFiles.Keys) {
        $targetFile = Join-Path $targetEfi $relativePath
        if (-not (Test-Path -LiteralPath $targetFile -PathType Leaf)) {
            throw "Copy verification failed: $relativePath"
        }
        $actualHash = (Get-FileHash -LiteralPath $targetFile -Algorithm SHA256).Hash.ToUpperInvariant()
        if ($actualHash -ne $expectedFiles[$relativePath]) {
            throw "Copied file hash does not match: $relativePath"
        }
    }

    Write-Host ''
    Write-Host 'USB preparation completed and file hashes match.' -ForegroundColor Green
    Write-Host 'On the Mac, hold Option/Alt, choose the USB EFI Boot, then use UEFI Shell:'
    Write-Host '  map -r'
    Write-Host '  fs0:                 (use the FS number that points to the USB)'
    Write-Host '  \EFI\OC\OpenCore.efi'
    Write-Host 'Then choose Windows on the internal disk in the OpenCore picker.'
}

try {
    Invoke-Main
} catch {
    Write-Host ''
    Write-Host ("Stopped: {0}" -f $_.Exception.Message) -ForegroundColor Red
    exit 1
}
