# Windows Audio Fix for MacBook Pro A1278 / MacBookPro9,2

أداة Windows لإنشاء فلاشة UEFI تشغّل رقعة ACPI قبل إقلاع Windows. هذا هو الحل الذي نجح فعلياً على جهاز MacBook Pro A1278 / MacBookPro9,2 يعمل بـ Windows 10 Enterprise LTSC 21H2، مع متحكم الصوت `PCI\VEN_8086&DEV_1E20&SUBSYS_72708086` وحالة Code 10.

**هذه ليست حزمة تعريف صوت تقليدية ولا تُصلح الصوت بعد تشغيل Windows.** الأداة تنسخ ملفات EFI إلى فلاشة FAT32. عند تشغيل Windows من خلال OpenCore على الفلاشة، يحمّل OpenCore رقعة `SSDT-PCI` وتعديل `BUF0` إلى `BUF1` قبل بدء Windows. لا تحتاج إلى macOS، ولا تعدّل قرص Windows أو EFI الداخلي. يلزم استخدام الفلاشة وطريقة الإقلاع هذه في كل مرة تريد فيها تطبيق الرقعة.

## الاستخدام السريع

1. استخدم فلاشة USB فارغة بنظام ملفات FAT32، واحتفظ بنسخة من أي ملفات مهمة عليها. إذا احتجت للتهيئة، تأكد من تحديد الفلاشة وحدها؛ الأداة نفسها لا تهيّئ أي قرص.
2. فك ملفات المشروع إلى مجلد على Windows.
3. شغّل `Start-Tool.cmd`، أو افتح PowerShell في المجلد وشغّل:

   ```powershell
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\New-AudioFixUsb.ps1
   ```

4. أدخل حرف الفلاشة مثل `E`، ثم اكتب `COPY` بعد التأكد من الحرف والملصق. الأداة تكتب مجلد `EFI` فقط، وترفض الاستمرار إذا لم تكن وحدة التخزين قابلة للإزالة وFAT32 أو كان عليها مجلد `EFI` مسبقاً.
5. أطفئ الماك. شغّله مع الضغط على **Option/Alt**، واختر **EFI Boot** الخاص بالفلاشة.
6. عند ظهور `Shell>`، اكتب:

   ```text
   map -r
   ```

   حدّد `FSx:` الذي مساره يحتوي على USB. في جهاز الاختبار كان `FS0:` هو USB و`FS1:` هو قرص SATA الداخلي؛ قد يختلف الترتيب على أجهزة أخرى.
7. اكتب رقم FS الصحيح، ثم شغّل OpenCore:

   ```text
   fs0:
   \EFI\OC\OpenCore.efi
   ```

   استبدل `fs0:` بالرقم الذي يشير إلى USB عند اختلافه.
8. من قائمة OpenCore اختر Windows الموجود على القرص الداخلي. بعد الدخول افحص الصوت وحالة متحكم الصوت في Device Manager.

## التراجع

لا يتغير Windows ولا EFI الداخلي. لإيقاف استخدام الرقعة، أطفئ الجهاز وانزع الفلاشة ثم أقلع من القرص الداخلي كالمعتاد. قد تعود مشكلة Code 10 لأن OpenCore لم يعد يحمّل الرقعة.

## النطاق والقيود

- التأكيد العملي الوحيد حتى الآن هو على MacBookPro9,2 / A1278 المشار إليه أعلاه؛ المستخدم أكد أن الصوت اشتغل بعد الإقلاع من نسخة OpenCore المصححة.
- قد تنطبق الفكرة على بعض أجهزة Sandy Bridge وIvy Bridge التي لديها قيد تخصيص PCI مشابه، لكنها ليست إصلاحاً مضموناً لكل جهاز A1278 أو لكل جهاز Mac.
- الملف `SSDT-PCI.aml` وملف الإعداد مُجهزان لهذا الاختبار تحديداً. لا تستخدم الحزمة على موديلات أخرى من دون فحص DSDT ومراجعة إعداد OpenCore.
- لا تثبّت OpenCore على EFI الداخلي ولا تغيّر تقسيم القرص كجزء من هذا الإجراء.
- إذا لم يظهر Windows في قائمة OpenCore أو ظهرت رسالة parse/config، أوقف التجربة، انزع USB، ثم أقلع من القرص الداخلي. لا تتجاوز أخطاء الإعداد.
- إذا اختفى Code 10 لكن لم يظهر جهاز إخراج صوت، فقد يحتاج كودك الصوتي إلى تعريف Boot Camp مناسب. هذه الأداة لا تحتوي تعريف Cirrus، ولا تثبّت تعريفاً من تلقاء نفسها.

## التحقق والمصادر

الأداة تتحقق من SHA-256 للملفات المضمنة قبل النسخ وبعده. تم استخدام نفس ملفات EFI التي جرّبها المستخدم وذكر بعدها أن الصوت يعمل. معلومات مصدر كل ملف وبصماته في [`PAYLOAD-SHA256SUMS.txt`](PAYLOAD-SHA256SUMS.txt) و[`THIRD-PARTY-NOTICES.md`](THIRD-PARTY-NOTICES.md).

- [OpenCore Legacy Patcher: شرح التعديلات](https://dortania.github.io/OpenCore-Legacy-Patcher/PATCHEXPLAIN.html)
- [OpenCore Legacy Patcher: مستودع المصدر والترخيص](https://github.com/dortania/OpenCore-Legacy-Patcher)
- [Acidanthera OpenCorePkg: المصدر والترخيص BSD-3-Clause](https://github.com/acidanthera/OpenCorePkg)
- [TianoCore EDK II: المصدر وترخيص UEFI Shell](https://github.com/tianocore/edk2/blob/master/License.txt)

This product includes software developed by Dortania and OpenCore Legacy Patcher contributors.

## English

This Windows PowerShell utility copies a tested OpenCore EFI payload to an already formatted FAT32 removable USB drive. It does not format disks, install a Windows driver, change Windows, or write to the Mac's internal EFI partition. Boot the Mac from the USB, use UEFI Shell to launch `\EFI\OC\OpenCore.efi`, then boot Windows through OpenCore so the ACPI patch is present before Windows starts. The confirmed test is one MacBookPro9,2 running Windows 10 Enterprise LTSC 21H2; similar models are not guaranteed.

The source code for this utility is MIT-licensed. Third-party EFI components retain their upstream licenses; see `THIRD-PARTY-NOTICES.md`.
